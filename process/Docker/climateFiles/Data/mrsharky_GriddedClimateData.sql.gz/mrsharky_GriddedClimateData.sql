-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mrsharky_GriddedClimateData
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Dataset`
--

DROP TABLE IF EXISTS `Dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dataset` (
  `Dataset_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Source_ID` smallint(5) unsigned NOT NULL,
  `Layer_ID` smallint(5) unsigned NOT NULL,
  `Statistic_ID` smallint(5) unsigned NOT NULL,
  `Level_ID` smallint(5) unsigned NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `InputFile` varchar(500) NOT NULL,
  `OutputFile` varchar(500) NOT NULL,
  `OutputFileName` varchar(500) NOT NULL,
  `VariableOfInterest` varchar(20) NOT NULL,
  `OriginalLocation` varchar(500) NOT NULL,
  `MetadataLocation` varchar(500) DEFAULT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `DatabaseStore` varchar(100) NOT NULL,
  `Units` varchar(100) DEFAULT NULL,
  `DefaultLevel` varchar(500) DEFAULT NULL,
  `Loaded` tinyint(1) NOT NULL,
  PRIMARY KEY (`Dataset_ID`),
  UNIQUE KEY `Name_U` (`Name`),
  UNIQUE KEY `OriginalLocation_U` (`OriginalLocation`),
  UNIQUE KEY `InputFile_U` (`InputFile`),
  UNIQUE KEY `OutputFile_U` (`OutputFile`),
  UNIQUE KEY `IDs_U` (`Source_ID`,`Layer_ID`,`Statistic_ID`,`Level_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dataset`
--

LOCK TABLES `Dataset` WRITE;
/*!40000 ALTER TABLE `Dataset` DISABLE KEYS */;
INSERT INTO `Dataset` VALUES (1,1,1,1,1,'NOAA|CPC Soil Moisture|Monthy Mean(Surface)','CPC Soil Moisture (V2).','sm/soilw.mon.mean.v2.nc','sm/soilw.mon.mean.v2.csv','soilw.mon.mean.v2.csv','soil','ftp://ftp.cdc.noaa.gov/Datasets/cpcsoil/soilw.mon.mean.v2.nc','','1948-01-01','2021-03-01','mrsharky_cpc_soilw_mon_mean_v2','mm','',0);
/*!40000 ALTER TABLE `Dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Layer`
--

DROP TABLE IF EXISTS `Layer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Layer` (
  `Layer_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `Parameter` varchar(100) NOT NULL,
  PRIMARY KEY (`Layer_ID`),
  UNIQUE KEY `Name_U` (`Name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Layer`
--

LOCK TABLES `Layer` WRITE;
/*!40000 ALTER TABLE `Layer` DISABLE KEYS */;
INSERT INTO `Layer` VALUES (1,'CPC Soil Moisture',NULL,'Soil Moisture');
/*!40000 ALTER TABLE `Layer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Level`
--

DROP TABLE IF EXISTS `Level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Level` (
  `Level_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(500) NOT NULL,
  `Description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`Level_ID`),
  UNIQUE KEY `Name_U` (`Name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Level`
--

LOCK TABLES `Level` WRITE;
/*!40000 ALTER TABLE `Level` DISABLE KEYS */;
INSERT INTO `Level` VALUES (1,'Surface',NULL);
/*!40000 ALTER TABLE `Level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Source`
--

DROP TABLE IF EXISTS `Source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Source` (
  `Source_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Source_ID`),
  UNIQUE KEY `Name_U` (`Name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Source`
--

LOCK TABLES `Source` WRITE;
/*!40000 ALTER TABLE `Source` DISABLE KEYS */;
INSERT INTO `Source` VALUES (1,'NOAA');
/*!40000 ALTER TABLE `Source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Statistic`
--

DROP TABLE IF EXISTS `Statistic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Statistic` (
  `Statistic_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Statistic_ID`),
  UNIQUE KEY `Name_U` (`Name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Statistic`
--

LOCK TABLES `Statistic` WRITE;
/*!40000 ALTER TABLE `Statistic` DISABLE KEYS */;
INSERT INTO `Statistic` VALUES (1,'Monthy Mean',NULL);
/*!40000 ALTER TABLE `Statistic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_inputData`
--

DROP TABLE IF EXISTS `s_inputData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_inputData` (
  `SourceName` varchar(1000) DEFAULT NULL,
  `DatasetName` varchar(1000) DEFAULT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `LayerName` varchar(1000) DEFAULT NULL,
  `LayerParameter` varchar(1000) DEFAULT NULL,
  `Statistic` varchar(1000) DEFAULT NULL,
  `Levels` varchar(1000) DEFAULT NULL,
  `InputFile` varchar(1000) DEFAULT NULL,
  `OutputFile` varchar(1000) DEFAULT NULL,
  `OutputFileName` varchar(1000) DEFAULT NULL,
  `VariableOfInterest` varchar(1000) DEFAULT NULL,
  `OrigLocation` varchar(1000) DEFAULT NULL,
  `MetadataLocation` varchar(1000) DEFAULT NULL,
  `StartDate` varchar(1000) DEFAULT NULL,
  `EndDate` varchar(1000) DEFAULT NULL,
  `DatabaseStore` varchar(1000) DEFAULT NULL,
  `Units` varchar(1000) DEFAULT NULL,
  `Blank` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_inputData`
--

LOCK TABLES `s_inputData` WRITE;
/*!40000 ALTER TABLE `s_inputData` DISABLE KEYS */;
INSERT INTO `s_inputData` VALUES ('NOAA','NOAA|CPC Soil Moisture|Monthy Mean(Surface)','CPC Soil Moisture (V2).','CPC Soil Moisture','Soil Moisture','Monthy Mean','Surface','sm/soilw.mon.mean.v2.nc','sm/soilw.mon.mean.v2.csv','soilw.mon.mean.v2.csv','soil','ftp://ftp.cdc.noaa.gov/Datasets/cpcsoil/soilw.mon.mean.v2.nc','','1948-01-01','2021-03-01','mrsharky_cpc_soilw_mon_mean_v2','mm',NULL);
/*!40000 ALTER TABLE `s_inputData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mrsharky_GriddedClimateData'
--
/*!50003 DROP PROCEDURE IF EXISTS `g_Dataset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `g_Dataset`()
BEGIN
SELECT
		Dataset_ID
		, Name
		, DatabaseStore 
		, OriginalLocation
		, StartDate
		, EndDate
		, Units
		, DefaultLevel
	FROM Dataset
	WHERE Loaded = 1
	ORDER BY Name ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-15 14:22:17
